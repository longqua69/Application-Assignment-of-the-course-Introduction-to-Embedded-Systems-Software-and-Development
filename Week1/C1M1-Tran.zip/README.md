##### /* Add Author and Project Details here */ #####
##### Author: Anh Hoang Chi Tran
##### Project: Week 1 Application Assignment
##### Course: Introduction to Embedded Systems Software and Development Environments
